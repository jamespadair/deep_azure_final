USE [adair-db]
GO

set ANSI_NULLS ON
GO
set QUOTED_IDENTIFIER ON
GO


-------------------------------------------------------
IF EXISTS (SELECT * FROM sys.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'dbo.uspBatchInsertBrentPetroPrices') AND TYPE IN (N'P'))
BEGIN
	DROP PROCEDURE dbo.uspBatchInsertBrentPetroPrices 
END
GO
CREATE PROCEDURE dbo.uspBatchInsertBrentPetroPrices
	@jsonObject nvarchar(max)
AS
BEGIN
	set NOCOUNT ON;

	DECLARE @InsertedRecords TABLE (
		[day] integer,
		price money
	);

	INSERT INTO dbo.brentPetroleumPrices([day],price)

	OUTPUT inserted.* INTO @InsertedRecords
	SELECT [Day],Price
	FROM OPENJSON (@jsonObject, '$.data' )
	WITH (
		day integer '$.day',
		price money '$.val'
	)
	SELECT * FROM @InsertedRecords
END
GO


-------------------------------------------------------
IF EXISTS (SELECT * FROM sys.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'dbo.uspBatchInsertHenryHubNaturalGasPrices') AND TYPE IN (N'P'))
BEGIN
	DROP PROCEDURE dbo.uspBatchInsertHenryHubNaturalGasPrices 
END
GO
CREATE PROCEDURE dbo.uspBatchInsertHenryHubNaturalGasPrices
	@jsonObject nvarchar(max)
AS
BEGIN
	set NOCOUNT ON;

	DECLARE @InsertedRecords TABLE (
		[day] integer,
		price money
	);

	INSERT INTO dbo.HenryHubNaturalGasPrices([day],price)

	OUTPUT inserted.* INTO @InsertedRecords
	SELECT [Day],Price
	FROM OPENJSON (@jsonObject, '$.data' )
	WITH (
		day integer '$.day',
		price money '$.val'
	)
	SELECT * FROM @InsertedRecords
END
GO