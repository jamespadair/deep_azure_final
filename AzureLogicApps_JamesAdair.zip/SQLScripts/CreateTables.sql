USE [adair-db]
GO

-------------------------------------------------------
IF EXISTS (SELECT * FROM sys.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'dbo.BrentPetroleumPrices') AND TYPE IN (N'U'))
BEGIN
	DROP TABLE dbo.BrentPetroleumPrices 
END
GO
CREATE TABLE dbo.BrentPetroleumPrices
(
	[Day] INT NOT NULL PRIMARY KEY,
	[Price] MONEY NOT NULL
)
GO

-------------------------------------------------------
IF EXISTS (SELECT * FROM sys.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'dbo.HenryHubNaturalGasPrices') AND TYPE IN (N'U'))
BEGIN
	DROP TABLE dbo.HenryHubNaturalGasPrices 
END
GO
CREATE TABLE dbo.HenryHubNaturalGasPrices
(
	[Day] INT NOT NULL PRIMARY KEY,
	[Price] MONEY NOT NULL
)
GO

-------------------------------------------------------
DROP VIEW dbo.vwPetroNaturalGasPrices
GO
CREATE VIEW dbo.vwPetroNaturalGasPrices
AS
SELECT convert(datetime, left(pet.[day],8)) [Day], pet.Price PetroPrice, ng.Price NGasPrice, pet.[day] DayNum 
FROM dbo.BrentPetroleumPrices pet, 
	dbo.HenryHubNaturalGasPrices ng
WHERE pet.[day]=ng.[day]
GO

