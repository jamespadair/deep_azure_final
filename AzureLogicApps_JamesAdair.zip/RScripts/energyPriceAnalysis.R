library(odbc)

#connect to SQL server, database adair-db and 
cn <- dbConnect(odbc::odbc(), .connection_string = "Driver={SQL Server};server=adair-sql-server.database.windows.net;database=adair-db;uid=deepazureguest;pwd=4Tr%&~RKVCw4xdB;")

#retrieve energy price data
startDate <- '20000101'
endDate <- '20181231'
sql <- paste('select Day, PetroPrice, NGasPrice from dbo.vwPetroNaturalGasPrices where DayNum between ', startDate, " and ", endDate)
energy <- dbGetQuery(cn, sql)
energy$Day = as.POSIXct(strptime(energy$Day, format="%Y-%m-%d","GMT"))

#increase margins bottom,left,top,right
par(mar=c(4,5,4,5))

#plot petroleum price series
plot(energy$Day, energy$PetroPrice, type="l", xlab="", ylab="", col="black", main="Prices in the Pre-Shale and Shale Periods")
mtext("Brent Petroleum Price ($ per Bbl", side=2, line=2.5)

abline(v=energy$Day[2230], col="red")

#prepare to plot on same graph
par(new=TRUE)

#plot natural gas price series
plot(energy$Day, energy$NGasPrice, type="l", xlab="", ylab="", col="blue", axes=FALSE)
mtext("HenryHub Natural Gas Prices ($ per Mil Btu)", side=4, col="blue", line=4)
axis(4, col="blue", col.axis="blue", las=1)


#add legend
legend("topright", legend=c("Petroleum","Natural Gas"), text.col=c("black","blue"), bty="n")

#get correlation coefficient and stat summary of Petroleum and Gas Prices over a few date ranges
corVal <- cor(energy$PetroPrice, energy$NGasPrice)
cat("correlation=",corVal)

print(' ');

summaryVal <- summary(energy)
print(summaryVal)
